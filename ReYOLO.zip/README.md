# Citation
Jianming Zhang, Zhuofan Zheng, Xianding Xie, Yan Gui, Gwang-Jun Kim. ReYOLO: A traffic sign detector based on network reparameterization and features adaptive weighting. Journal of Ambient Intelligence and Smart Environments, 2022, vol. 14, no. 4, pp. 317-334.  http://doi.org/10.3233/AIS-220038  

If you refer to these codes, please cite this paper.


# ReYOLO
* Jianming Zhang, Zhuofan Zheng, et al. ReYOLO: A Traffic Sign Detector based on Network Reparameterization and Features Adaptive Weighting

* Submitted to *Journal of Ambient Intelligence and Smart Environments*

If the above manuscript is accepted, the code and data to the manuscript will be publicly available for free.



## 代码文件核心修改为Model下的配置文件，其余部分可自行搭配

## 数据集配置文件来自GTSDB:https://benchmark.ini.rub.de/?section=gtsrb&subsection=news

## CCTSDB:https://github.com/csust7zhangjm/CCTSDB2021

## TT100K：https://github.com/halftop/TT100K_YOLO_Label.git 其中45类数据的标签文件由最多出现数量的45类进行筛选提取，可参考链接的标签格式

## 代码基于YOLOv5 2.0版本
